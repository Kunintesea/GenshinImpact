<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="map-new" tilewidth="32" tileheight="32" tilecount="3120" columns="24">
 <image source="map-new-side.png" width="768" height="4172"/>
</tileset>
