<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="bg-un" tilewidth="64" tileheight="64" tilecount="168" columns="3">
 <image source="bg-un.png" width="192" height="3584"/>
</tileset>
